package application;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Abbonato {
    private StringProperty codice;
    private StringProperty nome;
    private StringProperty cognome;
    private StringProperty indirizzo;
    private StringProperty telefono;
    private double costoAbbonamento;
    private StringProperty periodo;
    private StringProperty rivisteAbbonate;

    public Abbonato(String codice, String nome, String cognome, String indirizzo, String telefono, double costoAbbonamento, String periodo, String rivisteAbbonate) {
        this.codice = new SimpleStringProperty(codice);
        this.nome = new SimpleStringProperty(nome);
        this.cognome = new SimpleStringProperty(cognome);
        this.indirizzo = new SimpleStringProperty(indirizzo);
        this.telefono = new SimpleStringProperty(telefono);
        this.costoAbbonamento = costoAbbonamento;
        this.periodo = new SimpleStringProperty(periodo);
        this.rivisteAbbonate = new SimpleStringProperty (rivisteAbbonate);
    } 

    public String getCodice() {
        return codice.get();
    }

    public void setCodice(String codice) {
        this.codice.set(codice);
    }

    public StringProperty codiceProperty() {
        return codice;
    }

    public String getNome() {
        return nome.get();
    }

    public void setNome(String nome) {
        this.nome.set(nome);
    }

    public StringProperty nomeProperty() {
        return nome;
    }

    public String getCognome() {
        return cognome.get();
    }

    public void setCognome(String cognome) {
        this.cognome.set(cognome);
    }

    public StringProperty cognomeProperty() {
        return cognome;
    }

    public String getIndirizzo() {
        return indirizzo.get();
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo.set(indirizzo);
    }

    public StringProperty indirizzoProperty() {
        return indirizzo;
    }

    public String getTelefono() {
        return telefono.get();
    }

    public void setTelefono(String telefono) {
        this.telefono.set(telefono);
    }

    public StringProperty telefonoProperty() {
        return telefono;
    }

    public double getCostoAbbonamento() {
        return costoAbbonamento;
    }

    public void setCostoAbbonamento(double costoAbbonamento) {
        this.costoAbbonamento = costoAbbonamento;
    }

    public String getPeriodo() {
        return periodo.get();
    }

    public void setPeriodo(String periodo) {
        this.periodo.set(periodo);
    }

    public StringProperty periodoProperty() {
        return periodo;
    }

	public String getRivisteAbbonate() {
		return rivisteAbbonate.get();
	}

	public void setRivisteAbbonate(StringProperty rivisteAbbonate) {
		this.rivisteAbbonate = rivisteAbbonate;
	}
    
}
