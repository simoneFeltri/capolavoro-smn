package application;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AddController {

	private Stage stagee;

	@FXML
	private TextField Codice;

	@FXML
	private TextField Nome;

	@FXML
	private TextField Cognome;

	@FXML
	private TextField Telefono;

	@FXML
	private TextField Indirizzo;

	@FXML
	private TextField CostoAbbonamento;

	@FXML
	private TextField Periodo;

	@FXML
	private TextField RivisteAbbonate;

	@FXML
	private Button Add;

	@FXML
	private Button Chiudi;
	
	@FXML
	private TextField TextMod;
	
	@FXML
	private Button Modify;

	private ArrayList<Abbonato> elencoAbbonati;

	private GestioneOP casaEditrice;

	private Abbonato abbonato;

    public void setCasaEditrice(GestioneOP casaEditrice) {
        this.casaEditrice = casaEditrice;
    }
    
    public AddController() {
        this.casaEditrice = new GestioneOP();
    }

	public void setStage(Stage stagee) {
		this.stagee = stagee;
	}

	@FXML
	public void initialize(ArrayList<Abbonato>a) throws Exception {
	    elencoAbbonati = a;

	    Add.setOnAction(event -> {
	        String codiceText = Codice.getText();
	        String nomeText = Nome.getText();
	        String cognomeText = Cognome.getText();
	        String indirizzoText = Indirizzo.getText();
	        String telefonoText = Telefono.getText();
	        double costoAbbonamentoValue = Double.parseDouble(CostoAbbonamento.getText());
	        String periodoText = Periodo.getText();
	        String rivisteAbbonateText = RivisteAbbonate.getText();

	        // Verifica se la rivista esiste nel file delle riviste
	        boolean rivistaEsiste = verificaRivista(rivisteAbbonateText);
	        if (!rivistaEsiste) {
	            System.out.println("La rivista specificata non esiste nel file delle riviste.");
	            return;
	        }

	        // Altrimenti procedi con l'aggiunta dell'abbonato
	        boolean abbonatoEsiste = false;
	        for (int i=0;i<elencoAbbonati.size();i++) {
	            if (elencoAbbonati.get(i).getCodice().equals(codiceText)) {
	                abbonatoEsiste = true;
	                break;
	            }
	        }

	        if (!abbonatoEsiste) {
	            Abbonato nuovoAbbonato = new Abbonato(codiceText, nomeText, cognomeText, indirizzoText, telefonoText,
	                    costoAbbonamentoValue, periodoText, rivisteAbbonateText);
	            elencoAbbonati.add(nuovoAbbonato);
	            salvaDatiSuFile();
	            System.out.println("Abbonato aggiunto con successo.");
	            LOGGER.log("Dati dell' abbonato aggiunti: " + codiceText + " " + nomeText + " " + cognomeText);
	            clearFields();
	        } else {
	            System.out.println("L'abbonato con codice " + codiceText + " esiste già.");
	        }
	        chiudiFinestra();
	        //aggiunge un abbonato
	    });
	}

	private boolean verificaRivista(String nomeRivista) {
	    boolean rivistaEsiste = false;
	    try (BufferedReader reader = new BufferedReader(new FileReader("riviste.txt"))) {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            String[] parts = line.split(",");
	            String nomeRivistaFile = parts[0].trim();
	            if (nomeRivistaFile.equalsIgnoreCase(nomeRivista)) {
	                rivistaEsiste = true;
	                break;
	            }
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    return rivistaEsiste;
	    //controlla se la rivista a cui l'abboanto vuola bbonarsi esiste
	}
	
	@FXML
	private void modifica(ActionEvent event) {
	    String codiceAbbonato = Codice.getText();
	    String nuovoNome = Nome.getText();
	    String nuovoCognome = Cognome.getText();
	    String nuovoIndirizzo = Indirizzo.getText();
	    String nuovoTelefono = Telefono.getText();
	    double nuovoCostoAbbonamento = 0.0;
	    String nuovoPeriodo = Periodo.getText();
	    String nuovoRivisteAbbonate = RivisteAbbonate.getText();

	    try {
	        nuovoCostoAbbonamento = Double.parseDouble(CostoAbbonamento.getText());
	    } catch (NumberFormatException e) {
	        System.err.println("Errore: il costo dell'abbonamento deve essere un numero valido.");
	        return;
	    }

	    // Verifica se la nuova rivista esiste nel file delle riviste
	    boolean rivistaEsiste = verificaRivista(nuovoRivisteAbbonate);
	    if (!rivistaEsiste) {
	        System.out.println("La nuova rivista specificata non esiste nel file delle riviste.");
	        return;
	    }

	    ArrayList<String> nuoviDatiAbbonati = new ArrayList<>();

	    try (BufferedReader reader = new BufferedReader(new FileReader("dati_abbonati.txt"))) {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            String[] parts = line.split(",");
	            if (parts[0].equalsIgnoreCase(codiceAbbonato)) {
	                parts[1] = nuovoNome; 
	                parts[2] = nuovoCognome; 
	                parts[3] = nuovoIndirizzo; 
	                parts[4] = nuovoTelefono;
	                parts[5] = String.valueOf(nuovoCostoAbbonamento);
	                parts[6] = nuovoPeriodo;
	                parts[7] = nuovoRivisteAbbonate;
	            }
	            nuoviDatiAbbonati.add(String.join(",", parts)); 
	        }
	    } catch (IOException e) {
	        System.err.println("Errore durante la lettura del file dati_abbonati.txt.");
	        e.printStackTrace();
	        return;
	    }

	    try (PrintWriter writer = new PrintWriter(new FileWriter("dati_abbonati.txt"))) {
	        for (String linea : nuoviDatiAbbonati) {
	            writer.println(linea); 
	        }
	        System.out.println("Dati abbonato modificati con successo.");
	        LOGGER.log("Dati dell' abbonato modificati: " + codiceAbbonato + " " + nuovoNome + " " + nuovoCognome);
	    } catch (IOException e) {
	        System.err.println("Errore durante la scrittura nel file dati_abbonati.txt.");
	        e.printStackTrace();
	    }
	    chiudiFinestra();
	    //modica i dati di un abbonato già esistente
	}

	private void salvaDatiSuFile() {
	    try (PrintWriter writer = new PrintWriter(new FileWriter("dati_abbonati.txt", true))) {
	        for (Abbonato abbonato : elencoAbbonati) {
	            writer.println(abbonato.getCodice() + "," + abbonato.getNome() + "," + abbonato.getCognome() + ","
	                    + abbonato.getTelefono() + "," + abbonato.getIndirizzo() + "," + abbonato.getCostoAbbonamento() + ","
	                    + abbonato.getPeriodo() + "," + abbonato.getRivisteAbbonate());
	        }
	        System.out.println("Dati abbonati aggiunti al file.");
	    } catch (IOException e) {
	        System.err.println("Errore durante l'aggiunta dei dati abbonati al file: " + e.getMessage());
	    }
	    //salva i dati in un file "dati_abbonati.txt"
	}

	
	public void initData(Abbonato abbonato) {
		Codice.setText(abbonato.getCodice());
		Nome.setText(abbonato.getNome());
		Cognome.setText(abbonato.getCognome());
		Telefono.setText(abbonato.getTelefono());
		Indirizzo.setText(abbonato.getIndirizzo());
		CostoAbbonamento.setText(String.valueOf(abbonato.getCostoAbbonamento()));
		Periodo.setText(abbonato.getPeriodo());
		RivisteAbbonate.setText(abbonato.getRivisteAbbonate());
	}


	private void clearFields() {
	    Codice.clear();
	    Nome.clear();
	    Cognome.clear();
	    Indirizzo.clear();
	    Telefono.clear();
	    CostoAbbonamento.clear();
	    Periodo.clear();
	    RivisteAbbonate.clear();
	    //pulisce le Textfeild
	}
	
	@FXML
    private void chiudiFinestra() {
		Codice.getScene().getWindow().hide();
		//chiude la finestra
	}
	
}