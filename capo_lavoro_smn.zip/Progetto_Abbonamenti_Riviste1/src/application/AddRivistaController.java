package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class AddRivistaController {

    @FXML
    private TextField nomeRiv;

    @FXML
    private TextField genereRiv;

    @FXML
    private TextField tipoRiv;
    
    @FXML
    private Button modify;

	private Rivista rivista;
    
    public void initData(Rivista rivista) {
        this.rivista = rivista;
        nomeRiv.setText(rivista.getNome());
        genereRiv.setText(rivista.getGenere());
        tipoRiv.setText(rivista.getTipo());
    }

    private Stage stagee;

    public void setStage(Stage stagee) {
        this.stagee = stagee;
    }

    @FXML
    public void aggiungiRivista(ActionEvent event) {
        String nome = nomeRiv.getText().trim();
        String genere = genereRiv.getText().trim();
        String tipo = tipoRiv.getText().trim();

        if (nome.isEmpty() || genere.isEmpty() || tipo.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Errore", "Campi vuoti", "Per favore, compila tutti i campi.");
            return;
        }

        // Controllo se la rivista esiste gi� nel file
        if (rivistaEsisteGi�(nome, genere, tipo)) {
            showAlert(Alert.AlertType.ERROR, "Errore", "Rivista gi� esistente", "La rivista � gi� presente nel sistema.");
            return;
        }

        // Se la rivista non esiste, la aggiungo
        GestioneOP gestioneOP = new GestioneOP();
        Rivista nuovaRivista = new Rivista(nome, genere, tipo);
        gestioneOP.aggiungiRivista(nuovaRivista);
        System.out.println("Dati rivista modificati con successo.");
        LOGGER.log("Nuova rivista aggiunta: " + nome);
        clearFields();

        // Salva la rivista su file
        salvaSuFile(nuovaRivista);
        chiudiFinestra();
    }

    private boolean rivistaEsisteGi�(String nome, String genere, String tipo) {
        try (BufferedReader reader = new BufferedReader(new FileReader("riviste.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equalsIgnoreCase(nome) && parts[1].equalsIgnoreCase(genere) && parts[2].equalsIgnoreCase(tipo)) {
                    return true;
                }
            }
        } catch (IOException e) {
            System.err.println("Errore durante la lettura del file riviste.txt: " + e.getMessage());
        }
        return false;
    }
    
    @FXML
    private void modifica(ActionEvent event) {
        String nomeRivista = nomeRiv.getText();
        String nuovoGenere = genereRiv.getText();
        String nuovoTipo = tipoRiv.getText();

        if (nomeRivista.isEmpty() || nuovoGenere.isEmpty() || nuovoTipo.isEmpty()) {
            System.err.println("Errore: Tutti i campi devono essere compilati.");
            return;
        }

        ArrayList<String> nuoviDatiRiviste = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("riviste.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].trim().equalsIgnoreCase(nomeRivista)) {
                    parts[1] = nuovoGenere;
                    parts[2] = nuovoTipo;
                }
                nuoviDatiRiviste.add(String.join(",", parts));
            }
        } catch (IOException e) {
            System.err.println("Errore durante la lettura del file riviste.txt.");
            e.printStackTrace();
            return;
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter("riviste.txt"))) {
            for (String linea : nuoviDatiRiviste) {
                writer.println(linea);
            }
            System.out.println("Dati rivista modificati con successo.");
            LOGGER.log("Dati della rivista modificati: " + nomeRivista);
        } catch (IOException e) {
            System.err.println("Errore durante la scrittura nel file riviste.txt.");
            e.printStackTrace();
        }
        clearFields();
        chiudiFinestra();
    }

    private void salvaSuFile(Rivista rivista) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("riviste.txt", true))) {
            writer.println(rivista.getNome() + "," + rivista.getGenere() + "," + rivista.getTipo());
            System.out.println("Rivista salvata su file.");
        } catch (IOException e) {
            System.err.println("Errore durante il salvataggio della rivista su file: " + e.getMessage());
        }
    }
    
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void clearFields() {
        nomeRiv.clear();
        genereRiv.clear();
        tipoRiv.clear();
    }
    
    @FXML
    private void chiudiFinestra() {
		nomeRiv.getScene().getWindow().hide();
	}
}
