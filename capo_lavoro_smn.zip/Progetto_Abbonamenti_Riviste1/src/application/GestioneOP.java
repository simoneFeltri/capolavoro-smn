package application;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.StringProperty;

public class GestioneOP {
    private List<Rivista> riviste;
    private List<Abbonato> abbonati;

    public GestioneOP() {
        this.riviste = new ArrayList<>();
        this.abbonati = new ArrayList<>();
    }
    
    public void aggiungiRivista(Rivista nuovaRivista) {
        riviste.add(nuovaRivista);
    }
    
    

    public void aggiungiRivista(String nome, String genere, String tipo) {
        // Controlla se la rivista esiste gi�
        for (Rivista rivista : riviste) {
            if (rivista.getNome().equalsIgnoreCase(nome)) {
                LOGGER.log("Tentativo di aggiungere una rivista gi� esistente: " + nome);
                System.out.println("La rivista esiste gi�.");
                return;
            }
        }

        // Se la rivista non esiste, la aggiungi
        Rivista nuovaRivista = new Rivista(nome, genere, tipo);
        riviste.add(nuovaRivista);
        LOGGER.log("Nuova rivista aggiunta: " + nome);
        System.out.println("Rivista aggiunta con successo.");
    }
    
    public boolean esisteRivista(String nomeRivista) {
        for (int i=0;i<riviste.size();i++) {
            if (riviste.get(i).getNome().equalsIgnoreCase(nomeRivista)) {
                return true;
            }
        }
        return false;
    }


    // Aggiungi un nuovo abbonato
    public void aggiungiAbbonato(String codice, String nome, String cognome, String indirizzo, String telefono,
            double costoAbbonamento, String periodo, String rivisteAbbonate) {
        // Controlla se l'abbonato esiste gi�
        for (int i=0;i<abbonati.size();i++) {
            if (abbonati.get(i).getCodice().equalsIgnoreCase(codice)) {
                LOGGER.log("Tentativo di aggiungere un abbonato gi� esistente: " + codice);
                System.out.println("L'abbonato esiste gi�.");
                return;
            }
        }

        // Se l'abbonato non esiste, lo aggiungi
        Abbonato nuovoAbbonato = new Abbonato(codice, nome, cognome, indirizzo, telefono, costoAbbonamento, periodo ,rivisteAbbonate);
        abbonati.add(nuovoAbbonato);
        LOGGER.log("Nuovo abbonato aggiunto: " + codice);
        System.out.println("Abbonato aggiunto con successo.");
    }

    // Metodi per le altre operazioni

    public void cancellaRivista(String nomeRivista) {
        // Cerca la rivista nella lista
        for (Rivista rivista : riviste) {
            if (rivista.getNome().equalsIgnoreCase(nomeRivista)) {
                // Controlla se ci sono abbonati per questa rivista
                if (rivista.getAbbonati().isEmpty()) {
                    riviste.remove(rivista);
                    LOGGER.log("Rivista cancellata: " + nomeRivista);
                    System.out.println("Rivista cancellata con successo.");
                    return;
                } else {
                    System.out.println("Impossibile cancellare la rivista, ci sono abbonati ad essa.");
                    return;
                }
            }
        }
        System.out.println("Rivista non trovata.");
    }

    // Cancella un abbonato
    public void cancellaAbbonato(String codiceAbbonato) {
        // Cerca l'abbonato nella lista
        for (Abbonato abbonato : abbonati) {
            if (abbonato.getCodice().equalsIgnoreCase(codiceAbbonato)) {
                abbonati.remove(abbonato);
                LOGGER.log("Abbonato cancellato: " + codiceAbbonato);
                System.out.println("Abbonato cancellato con successo.");
                return;
            }
        }
        System.out.println("Abbonato non trovato.");
    }

    public void visualizzaTutteLeRiviste() {
        System.out.println("Elenco delle riviste:");
        for (Rivista rivista : riviste) {
            System.out.println(rivista.getNome());
        }
    }

    // Visualizza tutti gli abbonati
    public void visualizzaTuttiGliAbbonati() {
        System.out.println("Elenco degli abbonati:");
        for (Abbonato abbonato : abbonati) {
            System.out.println(abbonato.getCodice() + " - " + abbonato.getNome() + " " + abbonato.getCognome());
        }
    }

    public void visualizzaAbbonatiPerGenereRivista(String genere) {
        System.out.println("Elenco degli abbonati che hanno un abbonamento ad una rivista di genere " + genere + ":");
        for (Abbonato abbonato : abbonati) {
            //List<Rivista> rivisteAbbonamento = abbonato.getRivisteAbbonate();
            //for (Rivista rivista : rivisteAbbonamento) {
            //    if (rivista.getGenere().equalsIgnoreCase(genere)) {
                    System.out.println(abbonato.getCodice() + " - " + abbonato.getNome() + " " + abbonato.getCognome());
                    break;
                }
            }
    /// }

    public void modificaDatiRivista(String nomeRivista, String nuovoGenere, String nuovoTipo) {
        for (Rivista rivista : riviste) {
            if (rivista.getNome().equalsIgnoreCase(nomeRivista)) {
                rivista.setGenere(nuovoGenere);
                rivista.setTipo(nuovoTipo);
                LOGGER.log("Dati della rivista modificati: " + nomeRivista);
                System.out.println("Dati della rivista modificati con successo.");
                return;
            }
        }
        System.out.println("Rivista non trovata.");
    }

    
    public void modificaDatiAbbonato(String codiceAbbonato, String nuovoNome, String nuovoCognome,
            String nuovoIndirizzo, String nuovoTelefono, double nuovoCostoAbbonamento, String nuovoPeriodo, StringProperty nuovoRivisteAbbonate) {

        for (Abbonato abbonato : abbonati) {
            if (abbonato.getCodice().trim().equalsIgnoreCase(codiceAbbonato.trim())) {
                abbonato.setNome(nuovoNome);
                abbonato.setCognome(nuovoCognome);
                abbonato.setIndirizzo(nuovoIndirizzo);
                abbonato.setTelefono(nuovoTelefono);
                abbonato.setCostoAbbonamento(nuovoCostoAbbonamento);
                abbonato.setPeriodo(nuovoPeriodo);
                abbonato.setRivisteAbbonate(nuovoRivisteAbbonate);
                salvaDatiSuFile();
                LOGGER.log("Dati dell'abbonato modificati: " + codiceAbbonato);
                System.out.println("Dati dell'abbonato modificati con successo.");
                return;
            }
        }
        System.out.println("Abbonato non trovato.");
    }
    
    private void salvaDatiSuFile() {
	    try (PrintWriter writer = new PrintWriter(new FileWriter("dati_abbonati.txt"))) {
	        for (Abbonato abbonato : abbonati) {
	            writer.println(abbonato.getCodice() + "," + abbonato.getNome() + "," + abbonato.getCognome() + ","
	                    + abbonato.getTelefono() + "," + abbonato.getIndirizzo() + "," + abbonato.getCostoAbbonamento() + ","
	                    + abbonato.getPeriodo() + "," + abbonato.getRivisteAbbonate());
	        }
	        System.out.println("Dati abbonati salvati su file.");
	    } catch (IOException e) {
	        System.err.println("Errore durante il salvataggio dei dati abbonati su file: " + e.getMessage());
	    }
	}
}
