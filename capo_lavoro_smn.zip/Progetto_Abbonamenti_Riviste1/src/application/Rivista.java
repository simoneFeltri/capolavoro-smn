package application;

import java.util.ArrayList;
import java.util.List;

// Classe base per rappresentare una rivista
class Rivista {
    private String nome;
    private String genere;
    private String tipo;
    private List<Abbonato> abbonati;

    public String getNome() {
		return nome;
	}

	public String getGenere() {
		return genere;
	}

	public String getTipo() {
		return tipo;
	}

	public List<Abbonato> getAbbonati() {
		return abbonati;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setGenere(String genere) {
		this.genere = genere;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public void setAbbonati(List<Abbonato> abbonati) {
		this.abbonati = abbonati;
	}

	public Rivista(String nome, String genere, String tipo) {
        this.nome = nome;
        this.genere = genere;
        this.tipo = tipo;
        this.abbonati = new ArrayList<>();
    }

}

// Classe base per rappresentare un abbonato
