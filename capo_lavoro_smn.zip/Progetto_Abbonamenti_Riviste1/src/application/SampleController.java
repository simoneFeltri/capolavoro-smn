package application;

import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;

import javafx.scene.Node;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SampleController {

	@FXML
	private Button DoAggiungi;

	@FXML
	private Button DoCancella;

	@FXML
	private Button DoVisualizza;

	@FXML
	private Button DoCercaSpec;

	@FXML
	private TextField ZonaVisualizza;

	@FXML
	private Button DoModifica;

	@FXML
	private TextArea ZonaInfo;

	@FXML
	private Button DoInfoRivista;

	@FXML
	private Button DoInfoAbbonato;

	@FXML
	private Button DoNumero;

	@FXML
	private TextField ZonaNumero;

	@FXML
	private TextField TextMod;

	@FXML
	private Button DoModificaRiv;
	
	@FXML
	private TextField GenereRivAbb;
	
	@FXML
	private TextArea ZonaInfo1;

	private ArrayList<Abbonato> elencoAbbonati;

	private GestioneOP casaEditrice;

	public void setCasaEditrice(GestioneOP casaEditrice) {
		this.casaEditrice = casaEditrice;
	}

	@FXML
	private void DoAggiungi(ActionEvent event) throws Exception{
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Add.fxml"));
			Parent root = loader.load();
			AddController controller = loader.getController();
			//controller.setStage((Stage) ((Node) event.getSource()).getScene().getWindow());		
			Scene scene = new Scene(root);
			Stage stage = new Stage(); //(Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(scene);
			stage.show();
			controller.initialize(elencoAbbonati);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	private void DoAggRiv(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("AddRiv.fxml"));
			Parent root = loader.load();
			AddRivistaController controller = loader.getController();
			//controller.setStage((Stage) ((Node) event.getSource()).getScene().getWindow());		
			Scene scene = new Scene(root);
			Stage stage = new Stage(); //(Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	private void DoModifica(ActionEvent event) {
		String abbonatoId = TextMod.getText();
		Abbonato abbonato = null;

		try (Scanner scanner = new Scanner(new File("dati_abbonati.txt"))) {
			while (scanner.hasNextLine()) {
				String[] abbonatoData = scanner.nextLine().split(",");
				String id = abbonatoData[0];
				if (id.equals(abbonatoId)) {
					abbonato = new Abbonato(id, abbonatoData[1], abbonatoData[2], abbonatoData[3], abbonatoData[4],
							Double.parseDouble(abbonatoData[5]), abbonatoData[6], abbonatoData[7]);
					break;
				}
			}
		} catch (FileNotFoundException e) {
			System.err.println("Il file dati_abbonati.txt non � stato trovato.");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Errore durante la lettura del file dati_abbonati.txt.");
			e.printStackTrace();
		}

		if (abbonato != null) {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("Add.fxml"));
				Parent root = loader.load();
				AddController controller = loader.getController();
				controller.initData(abbonato);
				Stage stage = new Stage();
				stage.setScene(new Scene(root));
				stage.show();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		clearFields();
	}

	@FXML
	private void DoModificaRiv(ActionEvent event) {
		String nomeRivista = TextMod.getText();
		Rivista rivista = null;

		try (Scanner scanner = new Scanner(new File("riviste.txt"))) {
			while (scanner.hasNextLine()) {
				String[] rivistaData = scanner.nextLine().split(",");
				String nome = rivistaData[0];
				if (nome.equalsIgnoreCase(nomeRivista)) {
					rivista = new Rivista(nome, rivistaData[1], rivistaData[2]);
					break;
				}
			}
		} catch (FileNotFoundException e) {
			System.err.println("Il file riviste.txt non � stato trovato.");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Errore durante la lettura del file riviste.txt.");
			e.printStackTrace();
		}

		if (rivista != null) {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("AddRiv.fxml"));
				Parent root = loader.load();
				AddRivistaController controller = loader.getController();
				controller.initData(rivista);
				Stage stage = new Stage();
				stage.setScene(new Scene(root));
				stage.show();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		clearFields();
	}

	@FXML
	private void DoCancella(ActionEvent event) {
		String abbonatoId = TextMod.getText();
		boolean abbonatoTrovato = false;
		List<Abbonato> abbonatiDaMantenere = new ArrayList<>();
		try (Scanner scanner = new Scanner(new File("dati_abbonati.txt"))) {
			while (scanner.hasNextLine()) {
				String[] abbonatoData = scanner.nextLine().split(",");
				String id = abbonatoData[0];
				if (id.equals(abbonatoId)) {
					abbonatoTrovato = true;
					continue;
				}
				abbonatiDaMantenere.add(new Abbonato(id, abbonatoData[1], abbonatoData[2], abbonatoData[3],
						abbonatoData[4], Double.parseDouble(abbonatoData[5]), abbonatoData[6], abbonatoData[7]));
			}
		} catch (FileNotFoundException e) {
			System.err.println("Il file dati_abbonati.txt non � stato trovato.");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Errore durante la lettura del file dati_abbonati.txt.");
			e.printStackTrace();
		}

		if (!abbonatoTrovato) {
			System.err.println("Abbonato non trovato.");
			return;
		}

		try (PrintWriter writer = new PrintWriter(new FileWriter("dati_abbonati.txt"))) {
			for (Abbonato abbonato : abbonatiDaMantenere) {
				writer.println(abbonato.getCodice() + "," + abbonato.getNome() + "," + abbonato.getCognome() + ","
						+ abbonato.getIndirizzo() + "," + abbonato.getTelefono() + "," + abbonato.getCostoAbbonamento()
						+ "," + abbonato.getPeriodo() + "," +abbonato.getRivisteAbbonate());
			}
			System.out.println("Abbonato rimosso con successo.");
			LOGGER.log("Dati dell'abbonato sono stati rimossi ");
		} catch (IOException e) {
			System.err.println("Errore durante la scrittura nel file dati_abbonati.txt.");
			e.printStackTrace();
		}
		clearFields();
	}

	@FXML
	private void DoCancellaRiv(ActionEvent event) {
		String nomeRivista = TextMod.getText().trim();
		boolean rivistaTrovata = false;
		List<String> rivisteDaMantenere = new ArrayList<>();
		try (Scanner scanner = new Scanner(new File("riviste.txt"))) {
			while (scanner.hasNextLine()) {
				String rivistaLinea = scanner.nextLine();
				String[] rivistaData = rivistaLinea.split(",");
				String nome = rivistaData[0].trim();
				if (nome.equalsIgnoreCase(nomeRivista)) {
					rivistaTrovata = true;
					continue; // Salta l'aggiunta della rivista trovata
				}
				rivisteDaMantenere.add(rivistaLinea);
			}
		} catch (FileNotFoundException e) {
			System.err.println("Il file riviste.txt non � stato trovato.");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Errore durante la lettura del file riviste.txt.");
			e.printStackTrace();
		}

		if (!rivistaTrovata) {
			System.err.println("Rivista non trovata.");
			return;
		}

		try (PrintWriter writer = new PrintWriter(new FileWriter("riviste.txt"))) {
			for (String rivista : rivisteDaMantenere) {
				writer.println(rivista);
			}
			System.out.println("Rivista rimossa con successo.");
			LOGGER.log("La rivista � stata rimossa ");
		} catch (IOException e) {
			System.err.println("Errore durante la scrittura nel file riviste.txt.");
			e.printStackTrace();
		}
		clearFields();
	}

	@FXML
	private void DoVisualizza(ActionEvent event) {
		StringBuilder result = new StringBuilder();

		try (BufferedReader reader = new BufferedReader(new FileReader("dati_abbonati.txt"))) {
			String line;
			while ((line = reader.readLine()) != null) {
				result.append(line).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		ZonaInfo.setText(result.toString());
	}
	
	@FXML
    private void DoVisualizzaRiv(ActionEvent event) {
        StringBuilder result = new StringBuilder();

        try (BufferedReader reader = new BufferedReader(new FileReader("riviste.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        ZonaInfo1.setText(result.toString());
    }
	
	@FXML
    private void DoVisualizzaFull(ActionEvent event) {
        StringBuilder resultAbbonati = new StringBuilder();
        StringBuilder resultRiviste = new StringBuilder();

        // Visualizza abbonati
        resultAbbonati.append("Abbonati:\n");
        resultAbbonati.append("Codice, Nome, Cognome, Telefono, Indirizzo, Costo Abbonamento, Periodo\n");
        resultAbbonati.append("-----------------------------------------\n");
        try (BufferedReader readerAbbonati = new BufferedReader(new FileReader("dati_abbonati.txt"))) {
            String line;
            while ((line = readerAbbonati.readLine()) != null) {
                resultAbbonati.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        resultAbbonati.append("\n");

        // Visualizza riviste
        resultRiviste.append("Riviste:\n");
        resultRiviste.append("Nome, Genere, Tipo\n");
        resultRiviste.append("-----------------------------------------\n");
        try (BufferedReader readerRiviste = new BufferedReader(new FileReader("riviste.txt"))) {
            String line;
            while ((line = readerRiviste.readLine()) != null) {
                resultRiviste.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        ZonaInfo.setText(resultAbbonati.toString());
        ZonaInfo1.setText(resultRiviste.toString());
    }
	
	@FXML
	private void contaAbbonati(ActionEvent event) {
	    String nomeRivista = ZonaNumero.getText().trim();
	    int count = 0;
	    try (BufferedReader reader = new BufferedReader(new FileReader("dati_abbonati.txt"))) {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            String[] parts = line.split(",");
	            String rivisteAbbonate = parts[7].trim(); // Considerando che il nome della rivista � nella posizione 8 (indice 7)
	            if (rivisteAbbonate.equalsIgnoreCase(nomeRivista)) {
	                count++;
	            }
	        }
	        ZonaNumero.setText("Numero di abbonati per la rivista " + nomeRivista + ": " + count);
	    } catch (IOException e) {
	        System.err.println("Errore durante la lettura del file dati_abbonati.txt: " + e.getMessage());
	    }
	}
	
	public void initialaze()throws Exception {
		elencoAbbonati= new ArrayList<Abbonato>();
		BufferedReader br=new BufferedReader(new FileReader("dati_abbonati.txt"));
        String s=br.readLine();
        while(s!=null) {
            String vS[]=s.split(",");
            elencoAbbonati.add(new Abbonato(vS[0],vS[1],vS[2],vS[3],vS[4],Double.parseDouble(vS[5]),vS[6],vS[7]));
            s=br.readLine();
        }
        br.close();
	}
	
	@FXML
	private void visualizzaAbbonati(ActionEvent event) {
		System.out.println(elencoAbbonati.size());
	    String genereRivista = GenereRivAbb.getText().trim();
	    StringBuilder result = new StringBuilder();
	    try (BufferedReader reader = new BufferedReader(new FileReader("riviste.txt"))) {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            String[] parts = line.split(",");
	            String rivisteAbbonate = parts[2].trim(); // Considerando che il nome della rivista � nella posizione 8 (indice 7)
	            if (rivisteAbbonate.equalsIgnoreCase(genereRivista)) {
	            	for(int i=0;i<elencoAbbonati.size();i++) {
	            		if(elencoAbbonati.get(i).getRivisteAbbonate().equalsIgnoreCase(parts[0])) {
	            			result.append("Codice: ").append(elencoAbbonati.get(i).getCodice()).append(", Nome: ").append(elencoAbbonati.get(i).getNome()).append(", Cognome: ")
	                        .append(elencoAbbonati.get(i).getCognome()).append(", Telefono: ").append(elencoAbbonati.get(i).getTelefono()).append(", Indirizzo: ").append(elencoAbbonati.get(i).getIndirizzo())
	                        .append(", Costo Abbonamento: ").append(elencoAbbonati.get(i).getCostoAbbonamento()).append(", Periodo: ").append(elencoAbbonati.get(i).getPeriodo())
	                        .append(", Riviste Abbonate: ").append(elencoAbbonati.get(i).getRivisteAbbonate()).append("\n");
	            		}
	            	}
	            }
	        }
	        ZonaInfo1.setText(result.toString());
	    } catch (IOException e) {
	        System.err.println("Errore durante la lettura del file dati_abbonati.txt: " + e.getMessage());
	    }
	}

	private void clearFields() {
		TextMod.clear();
	}

    @FXML
    private void handleClose(ActionEvent event) {
        // Chiudi la finestra
    }
}
